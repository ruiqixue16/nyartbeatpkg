# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['nyartbeatpkg']

package_data = \
{'': ['*']}

install_requires = \
['bs4>=0.0.1,<0.0.2',
 'datetime>=4.7,<5.0',
 'lxml>=4.9.2,<5.0.0',
 'pandas>=1.5.2,<2.0.0',
 'pytest>=7.2.0,<8.0.0',
 'regex>=2022.10.31,<2023.0.0',
 'requests>=2.28.1,<3.0.0']

setup_kwargs = {
    'name': 'nyartbeatpkg',
    'version': '0.1.0',
    'description': 'A package for NY ArtBeat API',
    'long_description': "# nyartbeatpkg\n\nA package for NY ArtBeat API\n\n## About the package\nNew York City, dubbed “the art capital of U.S.”, has an incredible amount of art events available on any given day. Given the huge volume of shows and exhibitions, it is often hard for people to filter through this mass data to find the event that interests them the most. With the API provided by the New York Art Beat, a platform that provides a comprehensive list of art events and reviews, this package first incorporates the different event lists in a single dataset and then allows users to pinpoint their events of interest with a couple built-in search functions.\n\nThe API is consists of four categories and 24 subcategories, each has its own API in XML format. The database contains information on Name, Venue, Description, Image, Karma, Price, DateStart, DateEnd, PermanentEvent, Distance, Datum, Latitude, and Longitude (Children) of each Event (Parent). Some have missing values. The dataframe created by the function in this \nproject follows the same structure as the API's.\n\n## Installation\n\n```bash\n$ pip install nyartbeatpkg\n```\n\n## Usage\n\n1. Query NY ArtBeat's API in XML format with specified structure\n2. Retreive and create a dataframe concurred with the structure of the API\n3. Use various functions provided in the package to transform and clean dataframe, get event info, and a list of events that\nare available as of the day of the search\n\n## Contributing\n\nInterested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.\n\n## License\n\n`nyartbeatpkg` was created by Ruiqi Xue. It is licensed under the terms of the MIT license.\n\n## Credits\n\n`nyartbeatpkg` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).\n",
    'author': 'Ruiqi Xue',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
